function mostraEtapa(idAtual,idSeguinte)
{
document.getElementById(idAtual).style.display = "none";
document.getElementById(idSeguinte).style.display = "block"; 
 alert("Vamos comecar");
}

function selecionaCategoria(idBotao){
  //document.getElementById(idBotao).classList.remove('botaoNormal');    
  //document.getElementById(idBotao).classList.add('botaoPressionado');
  alert(idBotao + "Mudou");
}


function Etapa1(idAtual,idSeguinte)
{
document.getElementById(idAtual).style.display = "none";
document.getElementById(idSeguinte).style.display = "block"; 
}